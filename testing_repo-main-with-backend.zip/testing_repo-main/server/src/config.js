import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { randomBytes } from 'node:crypto'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const serverRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..')
try {
  process.loadEnvFile(join(serverRoot, '.env'))
} catch { /* no .env file — defaults apply */ }

const env = process.env
const production = env.NODE_ENV === 'production'
const dataDir = resolve(env.DATA_DIR || join(serverRoot, 'data'))
mkdirSync(dataDir, { recursive: true })

function loadSecret() {
  if (env.APP_SECRET && env.APP_SECRET.length >= 16) return env.APP_SECRET
  if (production) {
    console.warn(
      '[warn] APP_SECRET is not set. Falling back to data/app.secret — set APP_SECRET and back it up.',
    )
  }
  const file = join(dataDir, 'app.secret')
  if (existsSync(file)) return readFileSync(file, 'utf8').trim()
  const generated = randomBytes(32).toString('hex')
  writeFileSync(file, generated, { mode: 0o600 })
  return generated
}

const port = Number(env.PORT) || 4000

export const config = {
  production,
  port,
  dataDir,
  dbFile: env.DB_FILE ? resolve(env.DB_FILE) : join(dataDir, 'campus.db'),
  secret: loadSecret(),
  publicUrl: (env.PUBLIC_URL || `http://localhost:${port}`).replace(/\/$/, ''),
  allowAdminSignup: env.ALLOW_ADMIN_SIGNUP
    ? env.ALLOW_ADMIN_SIGNUP !== 'false'
    : !production,
  corsOrigin: env.CORS_ORIGIN || '',
  distDir: resolve(env.DIST_DIR || join(serverRoot, '..', 'dist')),
  bodyLimit: 40 * 1024 * 1024,
  tokenTtlSeconds: 60 * 60 * 24 * 7,
}

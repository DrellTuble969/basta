import { createHash } from 'node:crypto'
import { bad } from './validate.js'

const MAGIC = {
  'image/png': (b) => b.subarray(0, 4).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47])),
  'image/jpeg': (b) => b.subarray(0, 3).equals(Buffer.from([0xff, 0xd8, 0xff])),
  'image/webp': (b) => b.subarray(0, 4).toString() === 'RIFF' && b.subarray(8, 12).toString() === 'WEBP',
  'image/gif': (b) => b.subarray(0, 4).toString() === 'GIF8',
}

/**
 * Accepts a data: URL (a fresh upload) or a URL/path of an image we already store,
 * and returns the stored path "/api/assets/<sha256>". Empty input returns ''.
 * SVG is deliberately not accepted: it can carry scripts.
 */
export function storeImage(db, value, label, maxBytes) {
  if (value == null || value === '') return ''
  if (typeof value !== 'string') throw bad(`${label} must be an image.`)

  const known = /\/api\/assets\/([0-9a-f]{64})$/.exec(value)
  if (known) {
    if (!db.prepare('SELECT 1 FROM assets WHERE hash = ?').get(known[1])) {
      throw bad(`${label} is no longer available. Upload it again.`)
    }
    return `/api/assets/${known[1]}`
  }

  const split = value.indexOf(';base64,')
  const mime = value.startsWith('data:') ? value.slice(5, split) : ''
  if (split < 0 || !MAGIC[mime]) throw bad(`${label} must be a PNG, JPG, WebP or GIF image.`)
  const bytes = Buffer.from(value.slice(split + 8), 'base64')
  if (!bytes.length || !MAGIC[mime](bytes)) throw bad(`${label} is not a valid image file.`)
  if (bytes.length > maxBytes) throw bad(`${label} is too large (limit ${Math.round(maxBytes / 1048576)} MB).`)

  const hash = createHash('sha256').update(bytes).digest('hex')
  db.prepare('INSERT OR IGNORE INTO assets (hash, mime, data, created_at) VALUES (?,?,?,?)')
    .run(hash, mime, bytes, new Date().toISOString())
  return `/api/assets/${hash}`
}

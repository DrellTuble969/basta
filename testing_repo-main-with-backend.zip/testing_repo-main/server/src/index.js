import './quiet.js'
import { createServer } from 'node:http'
import { existsSync, rmSync } from 'node:fs'
import { config } from './config.js'
import { openDatabase } from './db.js'
import { deriveKey, verifyToken } from './crypto.js'
import { createLedger } from './ledger.js'
import { seedIfEmpty } from './seed.js'
import { createRouter, HttpError, readJson, send, serveStatic } from './http.js'
import { authRoutes } from './routes/auth.js'
import { activityRoutes } from './routes/activities.js'
import { recordRoutes } from './routes/records.js'
import { certificateRoutes } from './routes/certificates.js'
import { trustRoutes } from './routes/trust.js'

export function createApp(overrides = {}) {
  const cfg = { ...config, ...overrides }
  const db = openDatabase(cfg.dbFile)
  const ledger = createLedger(db, cfg.secret)
  const app = { db, ledger, config: cfg, jwtKey: deriveKey(cfg.secret, 'jwt') }
  seedIfEmpty(app)

  const router = createRouter()
  authRoutes(router, app)
  activityRoutes(router, app)
  recordRoutes(router, app)
  certificateRoutes(router, app)
  trustRoutes(router, app)

  function authenticate(req) {
    const header = req.headers.authorization || ''
    if (!header.startsWith('Bearer ')) return null
    const claims = verifyToken(app.jwtKey, header.slice(7))
    if (!claims) return null
    // Always reload the user: a deleted account or changed role takes effect immediately.
    return db.prepare('SELECT * FROM users WHERE id = ?').get(claims.sub) ?? null
  }

  const server = createServer(async (req, res) => {
    const url = new URL(req.url, 'http://localhost')
    const cors = cfg.corsOrigin
      ? {
        'access-control-allow-origin': cfg.corsOrigin,
        'access-control-allow-headers': 'authorization, content-type',
        'access-control-allow-methods': 'GET,POST,PUT,DELETE,OPTIONS',
        vary: 'Origin',
      }
      : {}
    try {
      if (req.method === 'OPTIONS') return send(res, 204, undefined, cors)

      const { route, params, pathMatched } = router.match(req.method, url.pathname)
      if (!route) {
        if (!url.pathname.startsWith('/api') && req.method === 'GET' &&
          serveStatic(res, cfg.distDir, url.pathname)) return undefined
        throw pathMatched
          ? new HttpError(405, 'Method not allowed.')
          : new HttpError(404, 'Not found.')
      }

      const opts = route.opts
      const user = opts.auth === false ? null : authenticate(req)
      if (!user && opts.auth !== false && opts.auth !== 'optional') {
        throw new HttpError(401, 'Please sign in to continue.')
      }
      if (opts.role && user?.role !== opts.role) {
        throw new HttpError(403, 'You do not have permission to do that.')
      }

      const ctx = {
        req, res, params, user, status: 200, headers: {},
        ip: req.socket.remoteAddress,
        query: Object.fromEntries(url.searchParams),
        body: ['POST', 'PUT'].includes(req.method) ? await readJson(req, cfg.bodyLimit) : {},
      }
      ctx.ctx = ctx
      const result = await route.handler(ctx)
      return send(res, result === undefined ? 204 : ctx.status, result, { ...cors, ...ctx.headers })
    } catch (error) {
      if (error instanceof HttpError) {
        return send(res, error.status, { error: error.message, ...error.extra }, cors)
      }
      console.error(error)
      return send(res, 500, { error: 'Something went wrong on the server.' }, cors)
    }
  })

  return { server, db, ledger, app }
}

// Run directly: `node src/index.js`
if (import.meta.url === `file://${process.argv[1]}`) {
  if (process.argv.includes('--reset') && existsSync(config.dbFile)) {
    for (const suffix of ['', '-wal', '-shm']) rmSync(config.dbFile + suffix, { force: true })
    console.log('Database reset.')
  }
  const { server } = createApp()
  server.listen(config.port, () => {
    console.log(`Campus Connect API  →  http://localhost:${config.port}/api/health`)
    console.log(`Admin sign-up from the UI: ${config.allowAdminSignup ? 'allowed' : 'disabled'}`)
  })
}

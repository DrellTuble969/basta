import { HttpError } from '../http.js'
import {
  activityOut, certificateOut, recordOut, signupOut, templateOut, userOut,
} from '../serializers.js'

const esc = (value) =>
  String(value ?? '').replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c])

function verifyPage(result, number) {
  const ok = result?.valid
  const rows = result
    ? [
      ['Recipient', result.recipientName],
      ['Activity', result.eventName],
      ['Activity date', result.eventDate],
      ['Approved service hours', result.hours],
      ['Issued', result.issuedAt?.slice(0, 10)],
      ['Issued by', `${result.issuer} · ${result.signatory}`],
    ].map(([k, v]) => `<tr><th>${esc(k)}</th><td>${esc(v)}</td></tr>`).join('')
    : ''
  const check = (label, pass) =>
    `<li class="${pass ? 'ok' : 'no'}">${pass ? '✓' : '✕'} ${esc(label)}</li>`
  return `<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Verify certificate ${esc(number)}</title>
<style>
:root{color-scheme:light dark;--bg:#f6f7f4;--card:#fff;--ink:#17201b;--mute:#5d6a62;--ok:#176b3a;--no:#b3261e;--line:#e1e5df}
@media(prefers-color-scheme:dark){:root{--bg:#101512;--card:#18201b;--ink:#eef2ee;--mute:#9aa8a0;--ok:#5fd18b;--no:#ff8a80;--line:#2a352e}}
body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.5 system-ui,sans-serif;display:grid;place-items:center;min-height:100vh;padding:16px;box-sizing:border-box}
main{background:var(--card);border:1px solid var(--line);border-radius:16px;max-width:520px;width:100%;padding:28px}
.badge{display:inline-block;padding:4px 12px;border-radius:99px;font-weight:600;font-size:14px;color:#fff;background:${ok ? 'var(--ok)' : 'var(--no)'}}
h1{font-size:22px;margin:14px 0 4px}p{color:var(--mute);margin:0 0 18px}
table{width:100%;border-collapse:collapse;margin-bottom:18px}th{text-align:left;color:var(--mute);font-weight:500;padding:8px 12px 8px 0;vertical-align:top;width:42%}td{padding:8px 0;font-weight:600}
tr{border-top:1px solid var(--line)}ul{list-style:none;padding:0;margin:0}li{padding:3px 0}.ok{color:var(--ok)}.no{color:var(--no)}small{color:var(--mute);display:block;margin-top:16px;word-break:break-all}
</style></head><body><main>
<span class="badge">${ok ? 'Authentic certificate' : result ? 'Verification failed' : 'Not found'}</span>
<h1>${ok ? 'This certificate is genuine' : result ? 'This certificate could not be verified' : 'No certificate with that number'}</h1>
<p>Certificate ${esc(number)}</p>
${rows ? `<table>${rows}</table>` : ''}
${result ? `<ul>${check('Digital signature matches the issued content', result.checks.signature)}${check(`Recorded in the service ledger (entry #${result.ledger.seq})`, result.checks.ledgerEntry)}</ul>` : ''}
<small>Every approval and certificate is recorded in a tamper-evident hash-chained ledger.</small>
</main></body></html>`
}

export function trustRoutes(router, app) {
  const { db, ledger, config } = app

  // Uploaded images. Content-addressed (hash of the bytes), so the URL never changes meaning.
  router.get('/api/assets/:hash', { auth: false }, ({ params, ctx }) => {
    const row = db.prepare('SELECT mime, data FROM assets WHERE hash = ?').get(params.hash)
    if (!row) throw new HttpError(404, 'Not found.')
    ctx.headers = {
      'content-type': row.mime,
      'cache-control': 'public, max-age=31536000, immutable',
      'content-security-policy': "default-src 'none'; sandbox",
      'cross-origin-resource-policy': 'cross-origin',
    }
    return Buffer.from(row.data)
  })

  router.get('/api/health', { auth: false }, () => ({
    ok: true,
    ledgerEntries: ledger.head()?.seq ?? 0,
    time: new Date().toISOString(),
  }))

  /** One call that hydrates everything the signed-in user is allowed to see. */
  router.get('/api/bootstrap', { auth: 'optional' }, ({ user }) => {
    const all = (sql, ...args) => db.prepare(sql).all(...args)
    const activities = all('SELECT * FROM activities ORDER BY rowid DESC')
      .map((row) => activityOut(row, config.publicUrl))
    if (!user) {
      return { user: null, activities, users: [], records: [], signups: [], certificates: [], templates: [] }
    }
    const admin = user.role === 'admin'
    return {
      user: userOut(user),
      activities,
      users: admin
        ? all(`SELECT * FROM users WHERE role = 'student' ORDER BY rowid`).map(userOut)
        : [userOut(user)],
      records: (admin
        ? all('SELECT * FROM records ORDER BY rowid DESC')
        : all(`SELECT * FROM records WHERE user_id = ? OR (student_id != '' AND student_id = ?) ORDER BY rowid DESC`,
          user.id, user.student_id)).map(recordOut),
      signups: (admin
        ? all('SELECT * FROM signups')
        : all('SELECT * FROM signups WHERE user_id = ?', user.id)).map(signupOut),
      certificates: (admin
        ? all('SELECT * FROM certificates ORDER BY rowid')
        : all('SELECT * FROM certificates WHERE user_id = ? ORDER BY rowid', user.id))
        .map((row) => certificateOut(row, config.publicUrl)),
      templates: admin
        ? all('SELECT * FROM templates ORDER BY rowid').map((row) => templateOut(row, config.publicUrl))
        : [],
    }
  })

  // ── Public verification ───────────────────────────────────────────────────
  function verify(number) {
    const row = db.prepare('SELECT * FROM certificates WHERE certificate_number = ?')
      .get(String(number).toUpperCase())
    if (!row) return null
    const cert = JSON.parse(row.data)
    const event = row.ledger_seq
      ? db.prepare('SELECT type, subject FROM ledger WHERE seq = ?').get(row.ledger_seq)
      : null
    const checks = {
      signature: ledger.certificateSignatureValid(cert, row.signature),
      ledgerEntry: Boolean(event) && event.type === 'certificate.issued' &&
        event.subject === row.certificate_number && ledger.verifyEntry(row.ledger_seq),
    }
    return {
      valid: checks.signature && checks.ledgerEntry,
      certificateNumber: row.certificate_number,
      recipientName: cert.recipientName,
      eventName: cert.eventName,
      eventDate: cert.eventDate,
      hours: cert.hours,
      issuedAt: cert.issuedAt,
      issuer: cert.template.organization,
      signatory: cert.template.signatory,
      ledger: { seq: row.ledger_seq },
      checks,
    }
  }

  router.get('/api/verify/:number', { auth: false }, ({ params }) => {
    const result = verify(params.number)
    if (!result) throw new HttpError(404, 'No certificate with that number.', { valid: false })
    return result
  })

  router.get('/verify/:number', { auth: false, html: true }, ({ params, ctx }) => {
    const result = verify(params.number)
    ctx.status = result ? 200 : 404
    ctx.headers = { 'content-security-policy': "default-src 'none'; style-src 'unsafe-inline'" }
    return verifyPage(result, params.number)
  })

  // ── Ledger (admin) ────────────────────────────────────────────────────────
  router.get('/api/ledger', { role: 'admin' }, ({ query }) => {
    const limit = Math.min(Math.max(Number(query.limit) || 50, 1), 200)
    const before = Number(query.before) || Number.MAX_SAFE_INTEGER
    return db.prepare('SELECT * FROM ledger WHERE seq < ? ORDER BY seq DESC LIMIT ?')
      .all(before, limit)
      .map((row) => ledger.rowToEntry(row))
  })

  /** Full audit: is the chain intact, and do the live tables match what the ledger recorded? */
  router.get('/api/ledger/verify', { role: 'admin' }, () => {
    const chain = ledger.verifyChain()
    const reconciliation = ledger.reconcile()
    return {
      ok: chain.ok && reconciliation.ok,
      checkedAt: new Date().toISOString(),
      chain,
      reconciliation,
    }
  })
}

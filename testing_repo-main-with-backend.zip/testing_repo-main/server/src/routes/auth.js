import { hashPassword, newId, signToken, verifyPassword } from '../crypto.js'
import { createLimiter, HttpError } from '../http.js'
import { userOut } from '../serializers.js'
import { bad, oneOf, text } from '../validate.js'

const DUMMY_HASH = hashPassword('not-a-real-password')

export function authRoutes(router, app) {
  const { db, config, jwtKey } = app
  const loginLimiter = createLimiter({ max: 8, windowMs: 10 * 60 * 1000 })
  const issue = (user) => signToken(jwtKey, { sub: user.id, role: user.role }, config.tokenTtlSeconds)

  router.post('/api/auth/login', { auth: false }, ({ body, ip }) => {
    const email = text(body.email, 'Email', { required: true, max: 200 }).toLowerCase()
    const password = typeof body.password === 'string' ? body.password : ''
    const key = `${ip}|${email}`
    if (!loginLimiter.check(key)) {
      throw new HttpError(429, 'Too many sign-in attempts. Try again in a few minutes.')
    }
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email)
    // Always run one scrypt so a missing account takes as long as a wrong password.
    const ok = verifyPassword(password, user?.password_hash ?? DUMMY_HASH) && user
    if (!ok) {
      loginLimiter.fail(key)
      throw new HttpError(401, 'That email and password combination was not found.')
    }
    loginLimiter.clear(key)
    return { token: issue(user), user: userOut(user) }
  })

  router.post('/api/auth/register', { auth: false }, ({ body, ctx }) => {
    const name = text(body.name, 'Name', { required: true, max: 100 })
    const email = text(body.email, 'Email', { required: true, max: 200 }).toLowerCase()
    const department = text(body.department, 'Department', { max: 100 })
    const role = oneOf(body.role || 'student', 'Role', ['student', 'admin'])
    const password = typeof body.password === 'string' ? body.password : ''
    if (!/^\S+@\S+\.\S+$/.test(email)) throw bad('Enter a valid email address.')
    if (password.length < 8 || !/[A-Z]/.test(password) || !/[0-9]/.test(password)) {
      throw bad('Use 8+ characters, including one uppercase letter and one number.')
    }
    if (role === 'admin' && !config.allowAdminSignup) {
      throw new HttpError(403, 'Admin accounts can only be created by an existing administrator.')
    }
    if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(email)) {
      throw new HttpError(409, 'An account with this email already exists.')
    }
    const year = new Date().getFullYear()
    let studentId = ''
    if (role === 'student') {
      do {
        studentId = `STU-${year}-${String(1000 + Math.floor(Math.random() * 9000))}`
      } while (db.prepare('SELECT 1 FROM users WHERE student_id = ?').get(studentId))
    }
    const user = {
      id: newId('u'), name, email, role, student_id: studentId, department,
    }
    db.prepare(
      `INSERT INTO users (id,name,email,password_hash,role,student_id,department,created_at)
       VALUES (?,?,?,?,?,?,?,?)`,
    ).run(user.id, name, email, hashPassword(password), role, studentId, department, new Date().toISOString())
    ctx.status = 201
    return { token: issue(user), user: userOut(user) }
  })

  router.get('/api/auth/me', ({ user }) => ({ user: userOut(user) }))
}

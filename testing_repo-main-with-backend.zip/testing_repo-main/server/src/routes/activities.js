import { HttpError } from '../http.js'
import { activityOut, recordOut } from '../serializers.js'
import { transaction } from '../db.js'
import { newId } from '../crypto.js'
import { storeImage } from '../assets.js'
import {
  bad, clock, integer, isoDate, oneOf, text, today,
} from '../validate.js'

const STATUSES = ['open', 'ongoing', 'completed', 'cancelled']

function parseActivity(db, body, existing) {
  const startTime = clock(body.startTime ?? existing?.start_time, 'Start time')
  const endTime = clock(body.endTime ?? existing?.end_time, 'End time')
  if (endTime <= startTime) throw bad('End time must be later than the start time.')
  return {
    title: text(body.title ?? existing?.title, 'Title', { required: true, max: 160 }),
    description: text(body.description ?? existing?.description, 'Description', { max: 5000 }),
    date: isoDate(body.date ?? existing?.date, 'Date'),
    startTime,
    endTime,
    location: text(body.location ?? existing?.location, 'Location', { required: true, max: 200 }),
    category: text(body.category ?? existing?.category, 'Category', { required: true, max: 60 }),
    capacity: integer(body.capacity ?? existing?.capacity, 'Capacity', { min: 1, max: 10000 }),
    status: oneOf(body.status ?? existing?.status ?? 'open', 'Status', STATUSES),
    organizer: text(body.organizer ?? existing?.organizer ?? 'Community Outreach Office', 'Organizer', { max: 120 }),
    image: text(body.image ?? existing?.image ?? '🤝', 'Icon', { max: 16 }),
    campaignImage: 'campaignImage' in body
      ? storeImage(db, body.campaignImage, 'Campaign picture', 12 * 1024 * 1024)
      : existing?.campaign_image ?? '',
  }
}

export function activityRoutes(router, app) {
  const { db, ledger, config } = app
  const out = (row) => activityOut(row, config.publicUrl)
  const find = (id) => db.prepare('SELECT * FROM activities WHERE id = ?').get(id)
  const mustFind = (id) => {
    const row = find(id)
    if (!row) throw new HttpError(404, 'Activity not found.')
    return row
  }

  router.get('/api/activities', { auth: 'optional' }, ({ query }) => {
    let items = db.prepare('SELECT * FROM activities ORDER BY rowid DESC').all().map(out)
    const includeCancelled = query.includeCancelled === 'true' || query.includeCancelled === '1'
    if (!includeCancelled) items = items.filter((i) => i.status !== 'cancelled')
    const q = query.search?.toLowerCase()
    if (q) items = items.filter((i) => `${i.title} ${i.location} ${i.description}`.toLowerCase().includes(q))
    if (query.category && query.category !== 'All categories') {
      items = items.filter((i) => i.category === query.category)
    }
    if (query.status && query.status !== 'All statuses') {
      items = items.filter((i) => i.status === query.status.toLowerCase())
    }
    return items
  })

  router.get('/api/activities/:id', { auth: 'optional' }, ({ params }) =>
    out(mustFind(params.id)))

  router.post('/api/activities', { role: 'admin' }, ({ body, user, ctx }) => {
    const a = parseActivity(db, body)
    const id = newId('a')
    const at = new Date().toISOString()
    transaction(db, () => {
      db.prepare(
        `INSERT INTO activities (id,title,description,date,start_time,end_time,location,category,
           spots_available,capacity,status,organizer,image,campaign_image,cancelled_at,created_at)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      ).run(id, a.title, a.description, a.date, a.startTime, a.endTime, a.location, a.category,
        a.capacity, a.capacity, a.status, a.organizer, a.image, a.campaignImage,
        a.status === 'cancelled' ? at : null, at)
      if (a.status === 'cancelled') {
        ledger.append({ type: 'activity.cancelled', subject: id, actor: user.id, payload: { activityId: id } })
      }
    })
    ctx.status = 201
    return out(find(id))
  })

  router.put('/api/activities/:id', { role: 'admin' }, ({ params, body, user }) => {
    const existing = mustFind(params.id)
    const a = parseActivity(db, body, existing)
    const registered = existing.capacity - existing.spots_available
    if (a.capacity < registered) {
      throw new HttpError(409, `Capacity cannot be lower than the ${registered} students already registered.`)
    }
    const at = new Date().toISOString()
    const nowCancelled = a.status === 'cancelled'
    transaction(db, () => {
      db.prepare(
        `UPDATE activities SET title=?,description=?,date=?,start_time=?,end_time=?,location=?,category=?,
           capacity=?,spots_available=?,status=?,organizer=?,image=?,campaign_image=?,
           cancelled_at=?,cancellation_reason=? WHERE id=?`,
      ).run(a.title, a.description, a.date, a.startTime, a.endTime, a.location, a.category,
        a.capacity, a.capacity - registered, a.status, a.organizer, a.image, a.campaignImage,
        nowCancelled ? existing.cancelled_at ?? at : null,
        nowCancelled ? existing.cancellation_reason : null, existing.id)
      if (nowCancelled && existing.status !== 'cancelled') {
        ledger.append({ type: 'activity.cancelled', subject: existing.id, actor: user.id, payload: { activityId: existing.id } })
      }
    })
    return out(find(existing.id))
  })

  router.post('/api/activities/:id/cancel', { role: 'admin' }, ({ params, body, user }) => {
    const existing = mustFind(params.id)
    const reason = text(body.reason, 'Reason', { max: 500 })
    transaction(db, () => {
      db.prepare(
        `UPDATE activities SET status='cancelled', cancellation_reason=?, cancelled_at=? WHERE id=?`,
      ).run(reason, new Date().toISOString(), existing.id)
      if (existing.status !== 'cancelled') {
        ledger.append({
          type: 'activity.cancelled', subject: existing.id, actor: user.id,
          payload: { activityId: existing.id, reason },
        })
      }
    })
    return out(find(existing.id))
  })

  router.delete('/api/activities/:id', { role: 'admin' }, ({ params }) => {
    const existing = mustFind(params.id)
    if (db.prepare('SELECT 1 FROM certificates WHERE event_id = ?').get(existing.id)) {
      throw new HttpError(409, 'Certificates were issued for this activity, so it cannot be deleted. Cancel it instead.')
    }
    db.prepare('DELETE FROM activities WHERE id = ?').run(existing.id)
    return { ok: true }
  })

  // ── Student actions ───────────────────────────────────────────────────────
  router.post('/api/activities/:id/signup', { role: 'student' }, ({ params, user, ctx }) =>
    transaction(db, () => {
      const activity = mustFind(params.id)
      if (activity.status === 'cancelled') {
        throw new HttpError(409, activity.cancellation_reason
          ? `This event has been cancelled: ${activity.cancellation_reason}`
          : 'This event has been cancelled.')
      }
      if (activity.status === 'completed') throw new HttpError(409, 'This activity has already finished.')
      if (db.prepare('SELECT 1 FROM signups WHERE activity_id=? AND user_id=?').get(activity.id, user.id)) {
        throw new HttpError(409, 'You are already registered.')
      }
      if (activity.spots_available < 1) throw new HttpError(409, 'This activity is full.')
      const at = new Date().toISOString()
      db.prepare('INSERT INTO signups (activity_id,user_id,created_at) VALUES (?,?,?)').run(activity.id, user.id, at)
      db.prepare('UPDATE activities SET spots_available = spots_available - 1 WHERE id = ?').run(activity.id)
      const hasRecord = db.prepare(
        `SELECT 1 FROM records WHERE activity_id = ? AND (user_id = ? OR (student_id != '' AND student_id = ?))`,
      ).get(activity.id, user.id, user.student_id)
      if (!hasRecord) {
        db.prepare(
          `INSERT INTO records (id,user_id,student_id,student_name,activity_id,activity_title,date,
             hours_logged,status,created_at) VALUES (?,?,?,?,?,?,?,0,'registered',?)`,
        ).run(newId('r'), user.id, user.student_id, user.name, activity.id, activity.title, activity.date, at)
      }
      ctx.status = 201
      return { ok: true }
    }))

  router.post('/api/activities/:id/hours', { role: 'student' }, ({ params, body, user, ctx }) =>
    transaction(db, () => {
      const activity = mustFind(params.id)
      if (activity.status === 'cancelled') throw new HttpError(409, 'This event was cancelled, so hours cannot be submitted.')
      const hours = Number(body.hours)
      if (!Number.isFinite(hours) || hours <= 0 || hours > 24) {
        throw bad('Enter a valid number of hours (up to 24).')
      }
      const rounded = Math.round(hours * 100) / 100
      // Anti-fraud: service can only be claimed once the activity has actually happened.
      if (activity.status !== 'completed' && activity.date > today()) {
        throw new HttpError(409, 'Hours can be submitted once the activity has taken place.')
      }
      const at = new Date().toISOString()
      const existing = db.prepare(
        `SELECT * FROM records WHERE activity_id = ? AND (user_id = ? OR (student_id != '' AND student_id = ?))`,
      ).get(activity.id, user.id, user.student_id)
      let id
      if (existing) {
        if (!['registered', 'rejected'].includes(existing.status)) {
          throw new HttpError(409, 'Hours for this activity have already been submitted.')
        }
        id = existing.id
        db.prepare(
          `UPDATE records SET user_id=?, hours_logged=?, status='pending', submitted_at=?, decided_at=NULL, decided_by=NULL WHERE id=?`,
        ).run(user.id, rounded, at, id)
      } else {
        id = newId('r')
        db.prepare(
          `INSERT INTO records (id,user_id,student_id,student_name,activity_id,activity_title,date,
             hours_logged,status,submitted_at,created_at) VALUES (?,?,?,?,?,?,?,?,'pending',?,?)`,
        ).run(id, user.id, user.student_id, user.name, activity.id, activity.title, activity.date, rounded, at, at)
      }
      ledger.append({
        type: 'hours.submitted', subject: id, actor: user.id,
        payload: { recordId: id, userId: user.id, studentId: user.student_id, activityId: activity.id, hours: rounded },
      })
      ctx.status = 201
      return recordOut(db.prepare('SELECT * FROM records WHERE id = ?').get(id))
    }))
}

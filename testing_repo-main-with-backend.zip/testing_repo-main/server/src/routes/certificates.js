import { HttpError } from '../http.js'
import { certificateOut, templateOut } from '../serializers.js'
import { transaction } from '../db.js'
import { newId, randomCode } from '../crypto.js'
import { storeImage } from '../assets.js'
import { bad, text } from '../validate.js'

function parseTemplate(db, body, base = {}) {
  const pick = (key) => (key in body ? body[key] : base[key])
  const nameY = Number(pick('nameY') ?? 58)
  if (!Number.isFinite(nameY) || nameY < 0 || nameY > 100) throw bad('Name position must be between 0 and 100.')
  return {
    name: text(pick('name'), 'Template name', { required: true, max: 100 }),
    description: text(pick('description'), 'Description', { max: 300 }),
    title: text(pick('title'), 'Certificate title', { required: true, max: 120 }),
    message: text(pick('message'), 'Message', { max: 2000 }),
    organization: text(pick('organization'), 'Organization', { required: true, max: 160 }),
    signatory: text(pick('signatory'), 'Signatory', { required: true, max: 120 }),
    position: text(pick('position'), 'Signatory position', { required: true, max: 120 }),
    nameY,
    designImage: storeImage(db, pick('designImage'), 'Design image', 20 * 1024 * 1024),
    overlayRecipientOnly: pick('overlayRecipientOnly') === true || pick('overlayRecipientOnly') === 'true',
  }
}

export function certificateRoutes(router, app) {
  const { db, ledger, config } = app
  const listTemplates = () =>
    db.prepare('SELECT * FROM templates ORDER BY rowid').all().map((row) => templateOut(row, config.publicUrl))

  // ── Templates ─────────────────────────────────────────────────────────────
  router.get('/api/templates', { role: 'admin' }, listTemplates)

  router.post('/api/templates', { role: 'admin' }, ({ body, ctx }) => {
    const data = parseTemplate(db, body)
    db.prepare('INSERT INTO templates (id,data,created_at) VALUES (?,?,?)')
      .run(newId('ct'), JSON.stringify(data), new Date().toISOString())
    ctx.status = 201
    return listTemplates()
  })

  router.put('/api/templates/:id', { role: 'admin' }, ({ params, body }) => {
    const row = db.prepare('SELECT * FROM templates WHERE id = ?').get(params.id)
    if (!row) throw new HttpError(404, 'Template not found.')
    const data = parseTemplate(db, body, JSON.parse(row.data))
    db.prepare('UPDATE templates SET data=?, updated_at=? WHERE id=?')
      .run(JSON.stringify(data), new Date().toISOString(), row.id)
    return listTemplates()
  })

  router.delete('/api/templates/:id', { role: 'admin' }, ({ params }) => {
    db.prepare('DELETE FROM templates WHERE id = ?').run(params.id)
    return listTemplates()
  })

  // ── Certificates ──────────────────────────────────────────────────────────
  router.get('/api/certificates', ({ user }) => {
    const rows = user.role === 'admin'
      ? db.prepare('SELECT * FROM certificates ORDER BY rowid').all()
      : db.prepare('SELECT * FROM certificates WHERE user_id = ? ORDER BY rowid').all(user.id)
    return rows.map((row) => certificateOut(row, config.publicUrl))
  })

  router.post('/api/certificates', { role: 'admin' }, ({ body, user, ctx }) =>
    transaction(db, () => {
      const student = db.prepare(`SELECT * FROM users WHERE id = ? AND role = 'student'`).get(String(body.userId))
      const event = db.prepare('SELECT * FROM activities WHERE id = ?').get(String(body.eventId))
      const templateRow = db.prepare('SELECT * FROM templates WHERE id = ?').get(String(body.templateId))
      if (!student || !event || !templateRow) {
        throw bad('Choose a valid student, completed event, and certificate template.')
      }
      if (event.status !== 'completed') {
        throw new HttpError(409, 'Certificates can only be granted for completed events.')
      }
      if (db.prepare('SELECT 1 FROM certificates WHERE user_id=? AND event_id=?').get(student.id, event.id)) {
        throw new HttpError(409, 'This student already has a certificate for this event.')
      }
      const base = JSON.parse(templateRow.data)
      const template = {
        ...base,
        id: templateRow.id,
        title: text(body.title, 'Title', { max: 120 }) || base.title,
        message: body.message === undefined ? base.message : text(body.message, 'Message', { max: 2000 }),
        organization: text(body.organization, 'Organization', { max: 160 }) || base.organization,
        signatory: text(body.signatory, 'Signatory', { max: 120 }) || base.signatory,
        position: text(body.position, 'Position', { max: 120 }) || base.position,
      }
      // Hours come from approved records on the server — never from the request.
      const hours = db.prepare(
        `SELECT COALESCE(SUM(hours_logged), 0) AS h FROM records
         WHERE activity_id = ? AND status = 'approved'
           AND (user_id = ? OR (student_id != '' AND student_id = ?))`,
      ).get(event.id, student.id, student.student_id).h

      let certificateNumber
      do {
        certificateNumber = `GN-${new Date().getFullYear()}-${randomCode(8)}`
      } while (db.prepare('SELECT 1 FROM certificates WHERE certificate_number = ?').get(certificateNumber))

      const cert = {
        userId: student.id,
        recipientName: text(body.recipientName, 'Recipient name', { max: 120 }) || student.name,
        eventId: event.id,
        eventName: event.title,
        eventDate: event.date,
        templateId: templateRow.id,
        template,
        hours,
        certificateNumber,
        issuedAt: new Date().toISOString(),
      }
      const signature = ledger.signCertificate(cert)
      const entry = ledger.append({
        type: 'certificate.issued', subject: certificateNumber, actor: user.id,
        payload: {
          certificateNumber, userId: student.id, eventId: event.id, hours,
          issuedAt: cert.issuedAt, signature,
        },
      })
      const id = newId('cert')
      db.prepare(
        `INSERT INTO certificates (id,user_id,event_id,certificate_number,data,signature,ledger_seq,issued_at)
         VALUES (?,?,?,?,?,?,?,?)`,
      ).run(id, student.id, event.id, certificateNumber, JSON.stringify(cert), signature, entry.seq, cert.issuedAt)
      ctx.status = 201
      return certificateOut(db.prepare('SELECT * FROM certificates WHERE id = ?').get(id), config.publicUrl)
    }))
}

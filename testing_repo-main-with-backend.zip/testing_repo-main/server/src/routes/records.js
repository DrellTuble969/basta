import { HttpError } from '../http.js'
import { recordOut } from '../serializers.js'
import { transaction } from '../db.js'

export function recordRoutes(router, app) {
  const { db, ledger } = app

  router.get('/api/records', ({ user }) => {
    const rows = user.role === 'admin'
      ? db.prepare('SELECT * FROM records ORDER BY rowid DESC').all()
      : db.prepare(
        `SELECT * FROM records WHERE user_id = ? OR (student_id != '' AND student_id = ?) ORDER BY rowid DESC`,
      ).all(user.id, user.student_id)
    return rows.map(recordOut)
  })

  const decide = (verdict) => ({ params, user }) =>
    transaction(db, () => {
      const record = db.prepare('SELECT * FROM records WHERE id = ?').get(params.id)
      if (!record) throw new HttpError(404, 'That submission could not be found.')
      if (record.status !== 'pending') {
        throw new HttpError(409, `This submission was already ${record.status}.`)
      }
      db.prepare('UPDATE records SET status=?, decided_at=?, decided_by=? WHERE id=?')
        .run(verdict, new Date().toISOString(), user.id, record.id)
      ledger.append({
        type: `hours.${verdict}`, subject: record.id, actor: user.id,
        payload: {
          recordId: record.id, userId: record.user_id, studentId: record.student_id,
          activityId: record.activity_id, hours: record.hours_logged,
        },
      })
      return recordOut(db.prepare('SELECT * FROM records WHERE id = ?').get(record.id))
    })

  router.post('/api/records/:id/approve', { role: 'admin' }, decide('approved'))
  router.post('/api/records/:id/reject', { role: 'admin' }, decide('rejected'))
}

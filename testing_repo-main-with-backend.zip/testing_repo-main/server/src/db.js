import './quiet.js'
import { DatabaseSync } from 'node:sqlite'

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('student','admin')),
  student_id TEXT NOT NULL DEFAULT '',
  department TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS activities (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  date TEXT NOT NULL,
  start_time TEXT NOT NULL,
  end_time TEXT NOT NULL,
  location TEXT NOT NULL DEFAULT '',
  category TEXT NOT NULL DEFAULT '',
  capacity INTEGER NOT NULL CHECK (capacity >= 0),
  spots_available INTEGER NOT NULL CHECK (spots_available >= 0),
  status TEXT NOT NULL CHECK (status IN ('open','ongoing','completed','cancelled')),
  organizer TEXT NOT NULL DEFAULT '',
  image TEXT NOT NULL DEFAULT '',
  campaign_image TEXT NOT NULL DEFAULT '',
  cancellation_reason TEXT,
  cancelled_at TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS signups (
  activity_id TEXT NOT NULL REFERENCES activities(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  PRIMARY KEY (activity_id, user_id)
);
CREATE TABLE IF NOT EXISTS records (
  id TEXT PRIMARY KEY,
  user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
  student_id TEXT NOT NULL DEFAULT '',
  student_name TEXT NOT NULL,
  activity_id TEXT NOT NULL,
  activity_title TEXT NOT NULL,
  date TEXT NOT NULL,
  hours_logged REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL CHECK (status IN ('registered','pending','approved','rejected')),
  submitted_at TEXT,
  decided_at TEXT,
  decided_by TEXT,
  created_at TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS records_student_activity
  ON records(student_id, activity_id) WHERE student_id != '';
CREATE TABLE IF NOT EXISTS templates (
  id TEXT PRIMARY KEY,
  data TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT
);
CREATE TABLE IF NOT EXISTS certificates (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  event_id TEXT NOT NULL,
  certificate_number TEXT NOT NULL UNIQUE,
  data TEXT NOT NULL,
  signature TEXT NOT NULL,
  ledger_seq INTEGER,
  issued_at TEXT NOT NULL,
  UNIQUE (user_id, event_id)
);
CREATE TABLE IF NOT EXISTS ledger (
  seq INTEGER PRIMARY KEY,
  type TEXT NOT NULL,
  subject TEXT NOT NULL,
  actor TEXT NOT NULL,
  payload TEXT NOT NULL,
  prev_hash TEXT NOT NULL,
  hash TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ledger_subject ON ledger(subject);
CREATE TABLE IF NOT EXISTS assets (
  hash TEXT PRIMARY KEY,
  mime TEXT NOT NULL,
  data BLOB NOT NULL,
  created_at TEXT NOT NULL
);
`

export function openDatabase(file) {
  const db = new DatabaseSync(file)
  db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;')
  db.exec(SCHEMA)
  return db
}

/** Run `fn` as one all-or-nothing unit. */
export function transaction(db, fn) {
  db.exec('BEGIN IMMEDIATE')
  try {
    const result = fn()
    db.exec('COMMIT')
    return result
  } catch (error) {
    db.exec('ROLLBACK')
    throw error
  }
}

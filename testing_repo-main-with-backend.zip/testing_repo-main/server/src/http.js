import { readFileSync, existsSync, statSync } from 'node:fs'
import { extname, join, normalize } from 'node:path'

export class HttpError extends Error {
  constructor(status, message, extra = {}) {
    super(message)
    this.status = status
    this.extra = extra
  }
}

/** A deliberately tiny router: method + path pattern -> handler. */
export function createRouter() {
  const routes = []
  const add = (method) => (pattern, opts, handler) => {
    if (typeof opts === 'function') [handler, opts] = [opts, {}]
    const keys = []
    const source = pattern.replace(/:([A-Za-z]+)/g, (_, key) => {
      keys.push(key)
      return '([^/]+)'
    })
    routes.push({ method, regex: new RegExp(`^${source}/?$`), keys, opts, handler })
  }
  return {
    get: add('GET'),
    post: add('POST'),
    put: add('PUT'),
    delete: add('DELETE'),
    match(method, pathname) {
      let pathMatched = false
      for (const route of routes) {
        const m = route.regex.exec(pathname)
        if (!m) continue
        pathMatched = true
        if (route.method !== method) continue
        const params = {}
        route.keys.forEach((key, i) => (params[key] = decodeURIComponent(m[i + 1])))
        return { route, params }
      }
      return { route: null, pathMatched }
    },
  }
}

export async function readJson(req, limit) {
  const chunks = []
  let size = 0
  for await (const chunk of req) {
    size += chunk.length
    if (size > limit) throw new HttpError(413, 'That upload is too large.')
    chunks.push(chunk)
  }
  if (!size) return {}
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'))
  } catch {
    throw new HttpError(400, 'The request body is not valid JSON.')
  }
}

export function send(res, status, body, headers = {}) {
  const isJson = typeof body !== 'string' && !Buffer.isBuffer(body)
  const payload = body === undefined ? '' : isJson ? JSON.stringify(body) : body
  res.writeHead(status, {
    'content-type': isJson ? 'application/json; charset=utf-8' : 'text/html; charset=utf-8',
    'x-content-type-options': 'nosniff',
    'referrer-policy': 'no-referrer',
    ...headers,
  })
  res.end(payload)
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.webp': 'image/webp',
  '.json': 'application/json',
  '.ico': 'image/x-icon',
  '.map': 'application/json',
}

/** Serve the built frontend (dist/) with SPA fallback. Returns false if unavailable. */
export function serveStatic(res, distDir, pathname) {
  if (!existsSync(join(distDir, 'index.html'))) return false
  const safe = normalize(decodeURIComponent(pathname)).replace(/^(\.\.[/\\])+/, '')
  let file = join(distDir, safe)
  if (!file.startsWith(distDir)) return false
  if (!existsSync(file) || !statSync(file).isFile()) file = join(distDir, 'index.html')
  const type = MIME[extname(file)] || 'application/octet-stream'
  const cache = file.includes('/assets/') ? 'public, max-age=31536000, immutable' : 'no-cache'
  res.writeHead(200, { 'content-type': type, 'cache-control': cache, 'x-content-type-options': 'nosniff' })
  res.end(readFileSync(file))
  return true
}

/** Fixed-window limiter, in memory. Enough to blunt password guessing. */
export function createLimiter({ max, windowMs }) {
  const hits = new Map()
  return {
    check(key) {
      const now = Date.now()
      const entry = hits.get(key)
      if (!entry || entry.reset < now) return true
      return entry.count < max
    },
    fail(key) {
      const now = Date.now()
      const entry = hits.get(key)
      if (!entry || entry.reset < now) hits.set(key, { count: 1, reset: now + windowMs })
      else entry.count += 1
      if (hits.size > 5000) for (const [k, v] of hits) if (v.reset < now) hits.delete(k)
    },
    clear: (key) => hits.delete(key),
  }
}

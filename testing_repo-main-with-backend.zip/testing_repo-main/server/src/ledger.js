import { canonical, deriveKey, hmacHex, safeEqual } from './crypto.js'

export const GENESIS = '0'.repeat(64)

/**
 * Proof-of-Service ledger.
 *
 * Every event that decides whether a student's service "counts" (hours submitted,
 * approved, rejected, certificate issued, event cancelled) is appended here as a
 * hash chain: each entry's hash covers the previous entry's hash, and is keyed
 * with a server secret (HMAC). Editing, deleting or inserting a past entry — even
 * with direct database access — breaks every hash after it, and without the secret
 * an attacker cannot repair the chain.
 *
 * `reconcile()` then compares the live tables against what the ledger says
 * *should* be true, so a hand-edited "approved" row or an inflated hour count is
 * caught even though the tables themselves are ordinary rows.
 */
export function createLedger(db, secret) {
  const key = deriveKey(secret, 'ledger')
  const certKey = deriveKey(secret, 'certificate')

  const entryHash = (e) =>
    hmacHex(
      key,
      canonical({
        seq: e.seq,
        type: e.type,
        subject: e.subject,
        actor: e.actor,
        payload: e.payload,
        prev: e.prev_hash,
        at: e.created_at,
      }),
    )

  const rowToEntry = (row) => ({ ...row, payload: JSON.parse(row.payload) })

  const head = () =>
    db.prepare('SELECT seq, hash FROM ledger ORDER BY seq DESC LIMIT 1').get()

  /** Append an event. Call inside the same transaction as the change it records. */
  function append({ type, subject, actor, payload }) {
    const last = head()
    const entry = {
      seq: (last?.seq ?? 0) + 1,
      type,
      subject,
      actor,
      payload,
      prev_hash: last?.hash ?? GENESIS,
      created_at: new Date().toISOString(),
    }
    entry.hash = entryHash(entry)
    db.prepare(
      `INSERT INTO ledger (seq,type,subject,actor,payload,prev_hash,hash,created_at)
       VALUES (?,?,?,?,?,?,?,?)`,
    ).run(
      entry.seq,
      type,
      subject,
      actor,
      JSON.stringify(payload),
      entry.prev_hash,
      entry.hash,
      entry.created_at,
    )
    return entry
  }

  /** Walk the whole chain. Returns the first break, if any. */
  function verifyChain() {
    let prev = GENESIS
    let expectedSeq = 1
    let length = 0
    for (const row of db.prepare('SELECT * FROM ledger ORDER BY seq').all()) {
      const entry = rowToEntry(row)
      if (entry.seq !== expectedSeq) {
        return { ok: false, length, brokenAt: expectedSeq, reason: 'missing or reordered entry' }
      }
      if (entry.prev_hash !== prev) {
        return { ok: false, length, brokenAt: entry.seq, reason: 'link to previous entry does not match' }
      }
      if (!safeEqual(entry.hash, entryHash(entry))) {
        return { ok: false, length, brokenAt: entry.seq, reason: 'entry contents were altered' }
      }
      prev = entry.hash
      expectedSeq += 1
      length += 1
    }
    return { ok: true, length, head: prev }
  }

  /** Cheap check of a single entry and its link to the one before it. */
  function verifyEntry(seq) {
    const row = db.prepare('SELECT * FROM ledger WHERE seq = ?').get(seq)
    if (!row) return false
    const entry = rowToEntry(row)
    if (!safeEqual(entry.hash, entryHash(entry))) return false
    if (seq === 1) return entry.prev_hash === GENESIS
    const before = db.prepare('SELECT hash FROM ledger WHERE seq = ?').get(seq - 1)
    return Boolean(before) && before.hash === entry.prev_hash
  }

  // ── Certificate signatures ────────────────────────────────────────────────
  const certificateCore = (c) => ({
    certificateNumber: c.certificateNumber,
    userId: c.userId,
    recipientName: c.recipientName,
    eventId: c.eventId,
    eventName: c.eventName,
    eventDate: c.eventDate,
    hours: c.hours,
    issuedAt: c.issuedAt,
    title: c.template?.title,
    organization: c.template?.organization,
    signatory: c.template?.signatory,
  })

  const signCertificate = (c) => hmacHex(certKey, canonical(certificateCore(c)))
  const certificateSignatureValid = (c, signature) =>
    safeEqual(signature, signCertificate(c))

  /** Latest ledger event per record (the ledger is the source of truth for status). */
  function reconcile() {
    const issues = []
    const latest = new Map()
    for (const row of db.prepare(
      `SELECT subject, type, payload FROM ledger
       WHERE type IN ('hours.submitted','hours.approved','hours.rejected') ORDER BY seq`,
    ).all()) {
      latest.set(row.subject, { type: row.type, payload: JSON.parse(row.payload) })
    }
    const expectedStatus = {
      'hours.submitted': 'pending',
      'hours.approved': 'approved',
      'hours.rejected': 'rejected',
    }
    for (const record of db.prepare('SELECT * FROM records').all()) {
      const event = latest.get(record.id)
      if (!event) {
        if (record.status !== 'registered') {
          issues.push({
            kind: 'record.unrecorded',
            id: record.id,
            detail: `status "${record.status}" has no matching ledger history`,
          })
        }
        continue
      }
      if (expectedStatus[event.type] !== record.status) {
        issues.push({
          kind: 'record.status',
          id: record.id,
          detail: `database says "${record.status}" but the ledger says "${expectedStatus[event.type]}"`,
        })
      } else if (Number(event.payload.hours) !== Number(record.hours_logged)) {
        issues.push({
          kind: 'record.hours',
          id: record.id,
          detail: `database has ${record.hours_logged} h but the ledger recorded ${event.payload.hours} h`,
        })
      }
    }
    for (const row of db.prepare('SELECT * FROM certificates').all()) {
      const cert = { ...JSON.parse(row.data) }
      if (!certificateSignatureValid(cert, row.signature)) {
        issues.push({
          kind: 'certificate.signature',
          id: row.certificate_number,
          detail: 'certificate contents no longer match their signature',
        })
      }
      const event = row.ledger_seq
        ? db.prepare('SELECT type, subject FROM ledger WHERE seq = ?').get(row.ledger_seq)
        : null
      if (!event || event.type !== 'certificate.issued' || event.subject !== row.certificate_number) {
        issues.push({
          kind: 'certificate.unrecorded',
          id: row.certificate_number,
          detail: 'no matching "certificate.issued" ledger entry',
        })
      }
    }
    return { ok: issues.length === 0, issues }
  }

  return {
    append,
    head,
    verifyChain,
    verifyEntry,
    reconcile,
    signCertificate,
    certificateSignatureValid,
    rowToEntry,
  }
}

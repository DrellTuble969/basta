// node:sqlite still prints an "experimental" notice on Node 22. Hide only that one;
// every other warning is printed as usual.
process.removeAllListeners('warning')
process.on('warning', (warning) => {
  if (String(warning?.message).includes('SQLite')) return
  console.error(`(node:${process.pid}) ${warning.name}: ${warning.message}`)
})

import {
  createHmac,
  hkdfSync,
  randomBytes,
  scryptSync,
  timingSafeEqual,
} from 'node:crypto'

/** Separate keys for separate jobs, all derived from one master secret. */
export function deriveKey(secret, label) {
  return Buffer.from(hkdfSync('sha256', secret, 'campus-connect', label, 32))
}

export const hmacHex = (key, text) =>
  createHmac('sha256', key).update(text).digest('hex')

export function safeEqual(a, b) {
  const x = Buffer.from(String(a))
  const y = Buffer.from(String(b))
  return x.length === y.length && timingSafeEqual(x, y)
}

/** Deterministic JSON: object keys sorted, so the same data always hashes the same. */
export function canonical(value) {
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`
  if (value && typeof value === 'object') {
    return `{${
      Object.keys(value).sort().filter((k) => value[k] !== undefined).map((k) =>
        `${JSON.stringify(k)}:${canonical(value[k])}`
      ).join(',')
    }}`
  }
  return JSON.stringify(value ?? null)
}

// ── Passwords ───────────────────────────────────────────────────────────────
export function hashPassword(password) {
  const salt = randomBytes(16)
  const hash = scryptSync(password, salt, 64)
  return `scrypt$${salt.toString('hex')}$${hash.toString('hex')}`
}

export function verifyPassword(password, stored) {
  const [scheme, saltHex, hashHex] = String(stored).split('$')
  if (scheme !== 'scrypt' || !saltHex || !hashHex) return false
  const expected = Buffer.from(hashHex, 'hex')
  const actual = scryptSync(password, Buffer.from(saltHex, 'hex'), expected.length)
  return timingSafeEqual(actual, expected)
}

// ── Login tokens (HS256 JWT, no library) ────────────────────────────────────
const b64 = (input) => Buffer.from(input).toString('base64url')

export function signToken(key, claims, ttlSeconds) {
  const now = Math.floor(Date.now() / 1000)
  const head = b64(JSON.stringify({ alg: 'HS256', typ: 'JWT' }))
  const body = b64(JSON.stringify({ ...claims, iat: now, exp: now + ttlSeconds }))
  const sig = createHmac('sha256', key).update(`${head}.${body}`).digest('base64url')
  return `${head}.${body}.${sig}`
}

export function verifyToken(key, token) {
  const [head, body, sig] = String(token).split('.')
  if (!head || !body || !sig) return null
  const expected = createHmac('sha256', key).update(`${head}.${body}`).digest('base64url')
  if (!safeEqual(sig, expected)) return null
  try {
    const claims = JSON.parse(Buffer.from(body, 'base64url').toString())
    return claims.exp > Math.floor(Date.now() / 1000) ? claims : null
  } catch {
    return null
  }
}

export const newId = (prefix) => `${prefix}_${randomBytes(6).toString('hex')}`

/** Unambiguous alphabet (no 0/O/1/I) so numbers survive being read aloud. */
export function randomCode(length) {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  const bytes = randomBytes(length)
  return Array.from(bytes, (b) => alphabet[b % alphabet.length]).join('')
}

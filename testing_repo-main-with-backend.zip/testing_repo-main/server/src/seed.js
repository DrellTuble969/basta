import { hashPassword } from './crypto.js'
import { transaction } from './db.js'

const now = () => new Date().toISOString()

const USERS = [
  ['u1', 'Maya Santos', 'maya@campus.edu', 'student', 'STU-2026-1042', 'Environmental Science'],
  ['u2', 'Alex Morgan', 'admin@campus.edu', 'admin', '', 'Student Affairs'],
]

// id, title, description, date, start, end, location, category, spots, capacity, status, organizer, image
const ACTIVITIES = [
  ['a1', 'Coastal Cleanup Morning', 'Join the campus community for a morning removing plastic waste and restoring the shoreline. Gloves, bags, and refreshments provided.', '2026-10-04', '07:30', '11:30', 'Baywalk Entrance, Manila', 'Environment', 18, 35, 'open', 'Green Campus Society', '🌊'],
  ['a2', 'Reading Buddies', 'Spend an afternoon reading with local elementary students and helping them build confidence with books.', '2026-10-07', '13:00', '16:00', 'San Isidro Community Center', 'Tutoring', 7, 20, 'open', 'Community Outreach Office', '📚'],
  ['a3', 'Campus Garden Day', 'Plant herbs, refresh the garden beds, and learn simple composting techniques with our grounds team.', '2026-10-11', '09:00', '12:00', 'North Quad Garden', 'Campus Care', 12, 24, 'open', 'Sustainability Council', '🌱'],
  ['a4', 'Community Pantry Packing', 'Pack essential food and care kits for distribution to families in our neighboring communities.', '2026-10-15', '10:00', '13:00', 'Student Union, Room 104', 'Community', 0, 30, 'open', 'Student Volunteer Network', '🤝'],
  ['a5', 'Welcome Week Wayfinders', 'Help new students and their families find their way around campus during orientation week.', '2026-10-20', '08:00', '12:00', 'Main Campus Gate', 'Campus Care', 9, 16, 'open', 'Student Affairs', '🧭'],
  ['a6', 'Park Tree Planting', 'Work alongside city partners to plant native trees and learn about urban biodiversity.', '2026-09-20', '08:00', '11:00', 'Rizal Park, Manila', 'Environment', 0, 25, 'completed', 'Green Campus Society', '🌳'],
]

// id, studentId, userId, name, activityId, hours, status, date
const RECORDS = [
  ['r1', 'STU-2026-1042', 'u1', 'Maya Santos', 'a6', 3, 'approved', '2026-09-20'],
  ['r2', 'STU-2026-1042', 'u1', 'Maya Santos', 'a1', 2.5, 'pending', '2026-09-17'],
  ['r3', 'STU-2026-2201', null, 'Noah Reyes', 'a3', 2, 'pending', '2026-09-16'],
  ['r4', 'STU-2026-1042', 'u1', 'Maya Santos', 'a5', 4, 'approved', '2026-09-12'],
  ['r5', 'STU-2026-3817', null, 'Liam Cruz', 'a2', 1.5, 'pending', '2026-09-10'],
]

export const DEFAULT_TEMPLATE = {
  name: 'Certificate of Service',
  description: 'Recognition for approved volunteer service.',
  title: 'Certificate of Service',
  message: 'for contributing {hours} approved volunteer hours to the campus community.',
  organization: 'Campus Connect · Student Community',
  signatory: 'Community Engagement Office',
  position: 'Community Engagement Office',
  nameY: 58,
  designImage: '',
  overlayRecipientOnly: false,
}

/** Fill an empty database with the demo data the frontend used to ship in mockData.js. */
export function seedIfEmpty({ db, ledger }) {
  const empty = db.prepare('SELECT COUNT(*) AS n FROM users').get().n === 0
  if (!empty) return false
  const at = now()
  const password = hashPassword('Campus123!')
  transaction(db, () => {
    for (const [id, name, email, role, studentId, department] of USERS) {
      db.prepare(
        `INSERT INTO users (id,name,email,password_hash,role,student_id,department,created_at)
         VALUES (?,?,?,?,?,?,?,?)`,
      ).run(id, name, email, password, role, studentId, department, at)
    }
    // Inserted last-to-first so "newest first" ordering (rowid DESC) matches the original lists.
    for (const a of [...ACTIVITIES].reverse()) {
      db.prepare(
        `INSERT INTO activities (id,title,description,date,start_time,end_time,location,category,
           spots_available,capacity,status,organizer,image,created_at)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      ).run(...a, at)
    }
    db.prepare('INSERT INTO signups (activity_id,user_id,created_at) VALUES (?,?,?)').run('a2', 'u1', at)
    for (const r of [...RECORDS].reverse()) {
      const [id, studentId, userId, name, activityId, hours, status, date] = r
      const title = ACTIVITIES.find((a) => a[0] === activityId)[1]
      db.prepare(
        `INSERT INTO records (id,user_id,student_id,student_name,activity_id,activity_title,date,
           hours_logged,status,submitted_at,decided_at,decided_by,created_at)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      ).run(id, userId, studentId, name, activityId, title, date, hours, status, at,
        status === 'approved' ? at : null, status === 'approved' ? 'system:seed' : null, at)
    }
    // The ledger must tell the same story as the tables, or reconcile() would flag the demo data.
    for (const [id, studentId, userId, , activityId, hours, status] of RECORDS) {
      const payload = { recordId: id, userId, studentId, activityId, hours }
      ledger.append({ type: 'hours.submitted', subject: id, actor: 'system:seed', payload })
      if (status === 'approved') {
        ledger.append({ type: 'hours.approved', subject: id, actor: 'system:seed', payload })
      }
    }
    db.prepare('INSERT INTO templates (id,data,created_at) VALUES (?,?,?)')
      .run('default', JSON.stringify(DEFAULT_TEMPLATE), at)
  })
  return true
}

// Database rows -> the exact JSON shapes the React app already consumes.

/** Stored images are kept as "/api/assets/<hash>"; clients get an absolute URL. */
export const assetUrl = (path, publicUrl) =>
  path && path.startsWith('/') ? `${publicUrl}${path}` : path || ''

export const userOut = (u) => ({
  id: u.id,
  name: u.name,
  email: u.email,
  role: u.role,
  studentId: u.student_id,
  department: u.department,
})

export function activityOut(a, publicUrl) {
  const out = {
    id: a.id,
    title: a.title,
    description: a.description,
    date: a.date,
    startTime: a.start_time,
    endTime: a.end_time,
    location: a.location,
    category: a.category,
    spotsAvailable: a.spots_available,
    capacity: a.capacity,
    status: a.status,
    organizer: a.organizer,
    image: a.image,
  }
  if (a.campaign_image) out.campaignImage = assetUrl(a.campaign_image, publicUrl)
  if (a.cancellation_reason != null) out.cancellationReason = a.cancellation_reason
  if (a.cancelled_at) out.cancelledAt = a.cancelled_at
  return out
}

export function recordOut(r) {
  const out = {
    id: r.id,
    userId: r.user_id ?? undefined,
    studentId: r.student_id,
    studentName: r.student_name,
    activityId: r.activity_id,
    activityTitle: r.activity_title,
    date: r.date,
    hoursLogged: r.hours_logged,
    status: r.status,
  }
  if (r.submitted_at) out.submittedAt = r.submitted_at
  return out
}

export const signupOut = (s) => ({ activityId: s.activity_id, studentId: s.user_id })

export function templateOut(t, publicUrl) {
  const data = JSON.parse(t.data)
  return {
    ...data,
    designImage: assetUrl(data.designImage, publicUrl),
    id: t.id,
    createdAt: t.created_at,
    updatedAt: t.updated_at ?? undefined,
  }
}

export function certificateOut(row, publicUrl) {
  const cert = JSON.parse(row.data)
  const code = row.signature.slice(0, 16).toUpperCase().match(/.{4}/g).join('-')
  return {
    ...cert,
    template: { ...cert.template, designImage: assetUrl(cert.template.designImage, publicUrl) },
    id: row.id,
    ledgerSeq: row.ledger_seq,
    verificationCode: code,
    verifyUrl: `${publicUrl}/verify/${row.certificate_number}`,
  }
}

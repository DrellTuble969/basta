import { HttpError } from './http.js'

export const bad = (message) => new HttpError(400, message)

export function text(value, label, { max = 200, required = false } = {}) {
  const v = typeof value === 'string' ? value.trim() : value == null ? '' : String(value).trim()
  if (required && !v) throw bad(`${label} is required.`)
  if (v.length > max) throw bad(`${label} must be ${max} characters or fewer.`)
  return v
}

export function isoDate(value, label) {
  const v = text(value, label, { required: true, max: 10 })
  const d = new Date(`${v}T00:00:00Z`)
  if (!/^\d{4}-\d{2}-\d{2}$/.test(v) || Number.isNaN(d.getTime()) || d.toISOString().slice(0, 10) !== v) {
    throw bad(`${label} must be a valid date (YYYY-MM-DD).`)
  }
  return v
}

export function clock(value, label) {
  const v = text(value, label, { required: true, max: 5 })
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(v)) throw bad(`${label} must be a time like 09:30.`)
  return v
}

export function integer(value, label, { min = 0, max = 100000 } = {}) {
  const n = Number(value)
  if (!Number.isInteger(n) || n < min || n > max) {
    throw bad(`${label} must be a whole number between ${min} and ${max}.`)
  }
  return n
}

export function oneOf(value, label, allowed) {
  if (!allowed.includes(value)) throw bad(`${label} must be one of: ${allowed.join(', ')}.`)
  return value
}

export const today = () => new Date().toISOString().slice(0, 10)

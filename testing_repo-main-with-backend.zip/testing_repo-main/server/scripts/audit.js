// Prints the integrity audit without needing to sign in:  npm run audit
// Exit code 1 if anything is wrong, so it can run in cron/CI.
import '../src/quiet.js'
import { config } from '../src/config.js'
import { openDatabase } from '../src/db.js'
import { createLedger } from '../src/ledger.js'

const ledger = createLedger(openDatabase(config.dbFile), config.secret)
const chain = ledger.verifyChain()
const recon = ledger.reconcile()
console.log(chain.ok
  ? `✓ Ledger chain intact (${chain.length} entries)`
  : `✕ Ledger chain BROKEN at entry #${chain.brokenAt}: ${chain.reason}`)
console.log(recon.ok
  ? '✓ Database matches the ledger'
  : `✕ ${recon.issues.length} mismatch(es) between the database and the ledger:`)
for (const issue of recon.issues) console.log(`   - [${issue.kind}] ${issue.id}: ${issue.detail}`)
process.exit(chain.ok && recon.ok ? 0 : 1)

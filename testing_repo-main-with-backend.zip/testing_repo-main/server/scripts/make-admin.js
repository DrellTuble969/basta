// Promote an existing account to admin (use with ALLOW_ADMIN_SIGNUP=false):
//   npm run make-admin -- someone@campus.edu
import '../src/quiet.js'
import { DatabaseSync } from 'node:sqlite'
import { config } from '../src/config.js'

const email = process.argv[2]
if (!email) {
  console.error('Usage: npm run make-admin -- someone@campus.edu')
  process.exit(1)
}
const db = new DatabaseSync(config.dbFile)
const { changes } = db.prepare(`UPDATE users SET role='admin', student_id='' WHERE email = ?`).run(email)
console.log(changes ? `${email} is now an admin.` : `No account found for ${email}.`)
process.exit(changes ? 0 : 1)

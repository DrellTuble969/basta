// DEMO ONLY: edits the database directly, the way an attacker (or a careless
// admin with a SQL console) would, to show the audit catching it.  npm run demo:tamper
import '../src/quiet.js'
import { DatabaseSync } from 'node:sqlite'
import { config } from '../src/config.js'

const db = new DatabaseSync(config.dbFile)
const result = db.prepare(`UPDATE records SET hours_logged = 40 WHERE id = 'r1'`).run()
console.log(result.changes
  ? `Changed record r1 to 40 hours behind the app's back.\nNow run:  npm run audit`
  : 'Record r1 not found (did you reset the demo data?).')

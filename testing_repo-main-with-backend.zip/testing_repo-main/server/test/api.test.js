import { test, before, after } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { DatabaseSync } from 'node:sqlite'

const dir = mkdtempSync(join(tmpdir(), 'campus-'))
process.env.DATA_DIR = dir
process.env.ALLOW_ADMIN_SIGNUP = 'true'
const { createApp } = await import('../src/index.js')

let base, srv, handle
const call = async (method, path, body, token) => {
  const res = await fetch(base + path, {
    method,
    headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
  })
  const text = await res.text()
  let json
  try { json = JSON.parse(text) } catch { json = text }
  return { status: res.status, body: json }
}
const login = async (email) =>
  (await call('POST', '/api/auth/login', { email, password: 'Campus123!' })).body.token

before(async () => {
  handle = createApp({ dbFile: join(dir, 't.db'), port: 0 })
  srv = handle.server
  await new Promise((r) => srv.listen(0, r))
  base = `http://127.0.0.1:${srv.address().port}`
})
after(() => { srv.close(); handle.db.close(); rmSync(dir, { recursive: true, force: true }) })

test('auth: login, wrong password, protected routes', async () => {
  const bad = await call('POST', '/api/auth/login', { email: 'maya@campus.edu', password: 'nope' })
  assert.equal(bad.status, 401)
  assert.equal(bad.body.error, 'That email and password combination was not found.')
  assert.equal((await call('GET', '/api/records')).status, 401)
  const t = await login('maya@campus.edu')
  const me = await call('GET', '/api/auth/me', undefined, t)
  assert.equal(me.body.user.studentId, 'STU-2026-1042')
  assert.equal(me.body.user.password_hash, undefined)
  assert.equal((await call('GET', '/api/ledger/verify', undefined, t)).status, 403)
})

test('register: validation, duplicates, admin flag', async () => {
  const r = await call('POST', '/api/auth/register', {
    name: 'Zed', email: 'zed@campus.edu', password: 'Passw0rdX', role: 'student', department: 'Art',
  })
  assert.equal(r.status, 201)
  assert.match(r.body.user.studentId, /^STU-\d{4}-\d{4}$/)
  const dup = await call('POST', '/api/auth/register', {
    name: 'Zed', email: 'ZED@campus.edu', password: 'Passw0rdX', role: 'student',
  })
  assert.equal(dup.status, 409)
  const weak = await call('POST', '/api/auth/register', { name: 'x', email: 'w@campus.edu', password: 'short', role: 'student' })
  assert.equal(weak.status, 400)
})

test('bootstrap is scoped by role', async () => {
  const anon = (await call('GET', '/api/bootstrap')).body
  assert.equal(anon.activities.length, 6)
  assert.equal(anon.records.length, 0)
  const student = (await call('GET', '/api/bootstrap', undefined, await login('maya@campus.edu'))).body
  assert.equal(student.records.length, 3)
  assert.ok(student.records.every((r) => r.studentId === 'STU-2026-1042'))
  assert.equal(student.users.length, 1)
  const admin = (await call('GET', '/api/bootstrap', undefined, await login('admin@campus.edu'))).body
  assert.equal(admin.records.length, 5)
  assert.ok(admin.users.every((u) => u.role === 'student'))
  assert.equal(admin.templates.length, 1)
  assert.equal(JSON.stringify(admin).includes('scrypt$'), false)
})

test('signup: capacity, duplicates, cancelled', async () => {
  const t = await login('maya@campus.edu')
  const ok = await call('POST', '/api/activities/a3/signup', {}, t)
  assert.equal(ok.status, 201)
  const again = await call('POST', '/api/activities/a3/signup', {}, t)
  assert.equal(again.status, 409)
  assert.equal(again.body.error, 'You are already registered.')
  const full = await call('POST', '/api/activities/a4/signup', {}, t)
  assert.equal(full.body.error, 'This activity is full.')
  const a3 = (await call('GET', '/api/activities')).body.find((a) => a.id === 'a3')
  assert.equal(a3.spotsAvailable, 11)
  const admin = await login('admin@campus.edu')
  await call('POST', '/api/activities/a5/cancel', { reason: 'Typhoon' }, admin)
  const cancelled = await call('POST', '/api/activities/a5/signup', {}, t)
  assert.equal(cancelled.body.error, 'This event has been cancelled: Typhoon')
  const listed = (await call('GET', '/api/activities')).body
  assert.ok(!listed.some((a) => a.id === 'a5'))
  const withCancelled = (await call('GET', '/api/activities?includeCancelled=true')).body
  assert.ok(withCancelled.some((a) => a.id === 'a5'))
})

test('hours: submit, anti-fraud for future events, approve once', async () => {
  const t = await login('maya@campus.edu')
  const admin = await login('admin@campus.edu')
  const create = await call('POST', '/api/activities', {
    title: 'Far future', category: 'Community', date: '2999-01-01', startTime: '09:00', endTime: '10:00',
    location: 'Hall', capacity: 5, description: '', status: 'open',
  }, admin)
  assert.equal(create.status, 201)
  const early = await call('POST', `/api/activities/${create.body.id}/hours`, { hours: 2 }, t)
  assert.equal(early.status, 409)
  const badHours = await call('POST', '/api/activities/a2/hours', { hours: 99 }, t)
  assert.equal(badHours.status, 400)
  const sub = await call('POST', '/api/activities/a2/hours', { hours: 2 }, t)
  assert.equal(sub.status, 201)
  assert.equal(sub.body.status, 'pending')
  const dup = await call('POST', '/api/activities/a2/hours', { hours: 2 }, t)
  assert.equal(dup.status, 409)
  assert.equal((await call('POST', `/api/records/${sub.body.id}/approve`, {}, t)).status, 403)
  const rej = await call('POST', `/api/records/${sub.body.id}/reject`, {}, admin)
  assert.equal(rej.body.status, 'rejected')
  assert.equal((await call('POST', `/api/records/${sub.body.id}/approve`, {}, admin)).status, 409)
  // rejected records can be resubmitted
  const re = await call('POST', '/api/activities/a2/hours', { hours: 1.5 }, t)
  assert.equal(re.body.status, 'pending')
  const ok = await call('POST', `/api/records/${re.body.id}/approve`, {}, admin)
  assert.equal(ok.body.status, 'approved')
  assert.equal(ok.body.hoursLogged, 1.5)
})

test('certificates: grant, public verify, duplicates, rules', async () => {
  const admin = await login('admin@campus.edu')
  const grant = (over = {}) => call('POST', '/api/certificates', {
    userId: 'u1', eventId: 'a6', templateId: 'default', recipientName: 'Maya Santos', ...over,
  }, admin)
  assert.equal((await grant({ eventId: 'a1' })).status, 409) // not completed
  const c = await grant()
  assert.equal(c.status, 201)
  assert.equal(c.body.hours, 3) // from approved record r1, not the request
  assert.match(c.body.certificateNumber, /^GN-\d{4}-[A-Z2-9]{8}$/)
  assert.equal((await grant()).status, 409) // duplicate
  const pub = await call('GET', `/api/verify/${c.body.certificateNumber}`)
  assert.equal(pub.status, 200)
  assert.equal(pub.body.valid, true)
  assert.equal(pub.body.recipientName, 'Maya Santos')
  const html = await call('GET', `/verify/${c.body.certificateNumber}`)
  assert.match(html.body, /This certificate is genuine/)
  assert.equal((await call('GET', '/api/verify/GN-2026-NOPENOPE')).status, 404)
  const mine = await call('GET', '/api/certificates', undefined, await login('maya@campus.edu'))
  assert.equal(mine.body.length, 1)
  assert.equal(handle.ledger.verifyChain().ok, true)
})

test('ledger catches tampering made directly in the database', async () => {
  const admin = await login('admin@campus.edu')
  const clean = (await call('GET', '/api/ledger/verify', undefined, admin)).body
  assert.equal(clean.ok, true, JSON.stringify(clean))

  const raw = new DatabaseSync(join(dir, 't.db'))
  // 1) Someone inflates approved hours straight in the table.
  raw.prepare(`UPDATE records SET hours_logged = 40 WHERE id = 'r1'`).run()
  // 2) Someone "approves" a pending record without going through the app.
  raw.prepare(`UPDATE records SET status = 'approved' WHERE id = 'r3'`).run()
  // 3) Someone edits a certificate's recipient.
  raw.prepare(`UPDATE certificates SET data = replace(data, 'Maya Santos', 'Mallory')`).run()
  const found = (await call('GET', '/api/ledger/verify', undefined, admin)).body
  assert.equal(found.ok, false)
  const kinds = found.reconciliation.issues.map((i) => i.kind).sort()
  assert.deepEqual(kinds, ['certificate.signature', 'record.hours', 'record.status'])
  const certNo = found.reconciliation.issues.find((i) => i.kind === 'certificate.signature').id
  assert.equal((await call('GET', `/api/verify/${certNo}`)).body.valid, false)

  // 4) Rewriting history inside the ledger itself breaks the chain.
  raw.prepare(`UPDATE ledger SET payload = replace(payload, '"hours":3', '"hours":30') WHERE seq = 2`).run()
  const chain = (await call('GET', '/api/ledger/verify', undefined, admin)).body.chain
  assert.equal(chain.ok, false)
  assert.equal(chain.brokenAt, 2)
  raw.close()
})

test('admin: activity edit keeps seat maths, template CRUD', async () => {
  const admin = await login('admin@campus.edu')
  const a = (await call('GET', '/api/activities')).body.find((x) => x.id === 'a2')
  assert.equal(a.capacity - a.spotsAvailable, 13)
  const low = await call('PUT', '/api/activities/a2', { capacity: 5 }, admin)
  assert.equal(low.status, 409)
  const up = await call('PUT', '/api/activities/a2', { capacity: 30 }, admin)
  assert.equal(up.body.spotsAvailable, 17)
  const created = await call('POST', '/api/templates', { name: 'Gold', title: 'Gold', organization: 'Org', signatory: 'S', position: 'P', message: 'hi {hours}', nameY: 50 }, admin)
  assert.equal(created.body.length, 2)
  const id = created.body.find((t) => t.name === 'Gold').id
  const edited = await call('PUT', `/api/templates/${id}`, { name: 'Gold 2' }, admin)
  assert.ok(edited.body.some((t) => t.name === 'Gold 2'))
  const del = await call('DELETE', `/api/templates/${id}`, undefined, admin)
  assert.equal(del.body.length, 1)
  assert.equal((await call('DELETE', '/api/activities/a6', undefined, admin)).status, 409) // has certificate
})

test('images: stored once, served by URL, validated', async () => {
  const admin = await login('admin@campus.edu')
  const png = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=='
  const make = (campaignImage) => call('POST', '/api/activities', {
    title: 'With picture', category: 'Community', date: '2026-12-01', startTime: '09:00', endTime: '10:00',
    location: 'Hall', capacity: 5, description: '', status: 'open', campaignImage,
  }, admin)
  const created = await make(png)
  assert.equal(created.status, 201)
  assert.match(created.body.campaignImage, /\/api\/assets\/[0-9a-f]{64}$/)
  const img = await fetch(created.body.campaignImage.replace(/^https?:\/\/[^/]+/, base))
  assert.equal(img.status, 200)
  assert.equal(img.headers.get('content-type'), 'image/png')
  assert.equal((await img.arrayBuffer()).byteLength, 70)
  // sending the URL back (what the edit form does) keeps the image
  const kept = await call('PUT', `/api/activities/${created.body.id}`, { campaignImage: created.body.campaignImage }, admin)
  assert.equal(kept.body.campaignImage, created.body.campaignImage)
  const cleared = await call('PUT', `/api/activities/${created.body.id}`, { campaignImage: '' }, admin)
  assert.equal(cleared.body.campaignImage, undefined)
  assert.equal((await make('data:image/svg+xml;base64,PHN2Zz48L3N2Zz4=')).status, 400)
  assert.equal((await make('data:image/png;base64,AAAA')).status, 400)
  assert.equal((await make('https://evil.example/x.png')).status, 400)
})

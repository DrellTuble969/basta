// Contract test: runs the app's real src/services/api.js against the real server,
// with a localStorage shim, to prove the React screens' synchronous reads keep working.
import { test, before, after } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

const dir = mkdtempSync(join(tmpdir(), 'campus-client-'))
process.env.DATA_DIR = dir
const { createApp } = await import('../src/index.js')

const memory = new Map()
globalThis.localStorage = {
  getItem: (k) => (memory.has(k) ? memory.get(k) : null),
  setItem: (k, v) => memory.set(k, String(v)),
  removeItem: (k) => memory.delete(k),
}
const redirects = []
globalThis.window = { location: { assign: (to) => redirects.push(to) } }

let handle, origin
const realFetch = globalThis.fetch
globalThis.fetch = (url, init) => realFetch(String(url).startsWith('/') ? origin + url : url, init)

const api = await import('../../src/services/api.js')
const { store, authService, activityService, participationService, certificateService, certificateTemplateService } = api

before(async () => {
  handle = createApp({ dbFile: join(dir, 'c.db'), port: 0 })
  await new Promise((r) => handle.server.listen(0, r))
  origin = `http://127.0.0.1:${handle.server.address().port}`
})
after(() => { handle.server.close(); handle.db.close(); rmSync(dir, { recursive: true, force: true }) })

test('signed-out screens get public activities', async () => {
  assert.equal(await api.hydrate(), true)
  assert.equal(store.read('campus_activities', []).length, 6)
  assert.equal(store.read('campus_session', null), null)
  assert.deepEqual(store.read('campus_records', []), [])
})

test('student journey through the service layer', async () => {
  await assert.rejects(authService.login('maya@campus.edu', 'wrong'), /email and password/)
  const user = await authService.login('maya@campus.edu', 'Campus123!')
  assert.equal(user.role, 'student')
  assert.equal(store.read('campus_session', null).id, 'u1')
  assert.equal(participationService.getRecordsForUser(user).length, 3)

  await participationService.signUp('a3', user)
  assert.ok(store.read('campus_signups', []).some((s) => s.activityId === 'a3' && s.studentId === user.id))
  assert.equal(store.read('campus_activities', []).find((a) => a.id === 'a3').spotsAvailable, 11)
  await assert.rejects(participationService.signUp('a3', user), /already registered/)
  await assert.rejects(participationService.signUp('a4', user), /full/)

  const record = await participationService.logHours('a2', '2', user)
  assert.equal(record.status, 'pending')
  assert.ok(participationService.getRecordsForUser(user).some((r) => r.id === record.id))
  await assert.rejects(participationService.logHours('a2', '2', user), /already been submitted/)
  const found = await activityService.getAll({ search: 'garden', category: 'All categories', status: 'All statuses' })
  assert.deepEqual(found.map((a) => a.id), ['a3'])
  assert.equal(store.read('campus_certificate_templates', []).length, 0) // students never receive admin data
})

test('admin journey through the service layer', async () => {
  authService.logout()
  assert.equal(store.read('campus_session', null), null)
  const admin = await authService.login('admin@campus.edu', 'Campus123!')
  assert.equal(admin.role, 'admin')
  const pending = participationService.getAllRecords().filter((r) => r.status === 'pending')
  assert.ok(pending.length >= 4)
  const approved = await participationService.approveHours(pending[0].id)
  assert.equal(approved.status, 'approved')
  assert.equal(participationService.getAllRecords().find((r) => r.id === approved.id).status, 'approved')

  const cert = await certificateService.grant({
    userId: 'u1', eventId: 'a6', templateId: 'default', recipientName: 'Maya Santos',
    title: 'Certificate of Service', message: 'for {hours} hours', organization: 'Org', signatory: 'S', position: 'P',
  })
  assert.equal(cert.hours, 3)
  assert.equal(certificateService.getForUser('u1').length, 1)
  assert.match(cert.verifyUrl, /\/verify\/GN-/)
  await assert.rejects(certificateService.grant({ userId: 'u1', eventId: 'a6', templateId: 'default' }), /already has a certificate/)

  const list = await certificateTemplateService.save({
    name: 'Blue', description: '', title: 'T', message: 'm', organization: 'O', signatory: 'S', position: 'P', nameY: 60,
    designImage: '', overlayRecipientOnly: false,
  })
  assert.equal(list.length, 2)
  const blue = list.find((t) => t.name === 'Blue')
  const updated = await certificateTemplateService.save({ ...blue, name: 'Navy' })
  assert.ok(updated.some((t) => t.name === 'Navy'))
  await certificateTemplateService.delete(blue.id)
  assert.equal(certificateTemplateService.getAll().length, 1)

  const created = await activityService.create({
    title: 'New', category: 'Community', date: '2026-12-12', startTime: '09:00', endTime: '11:00',
    location: 'Hall', capacity: 10, description: 'd', status: 'open', campaignImage: '', organizer: 'Community Outreach Office',
  })
  assert.equal(store.read('campus_activities', []).some((a) => a.id === created.id), true)
  await activityService.cancel(created.id, 'Rain')
  assert.equal(store.read('campus_activities', []).find((a) => a.id === created.id).status, 'cancelled')
  await activityService.delete(created.id)
  assert.equal(store.read('campus_activities', []).some((a) => a.id === created.id), false)
})

test('expired login returns to the sign-in page; offline server is reported', async () => {
  localStorage.setItem('campus_token', 'garbage.token.value')
  await assert.rejects(participationService.approveHours('r3'), /sign in/i)
  assert.deepEqual(redirects, ['/login'])
  assert.equal(localStorage.getItem('campus_token'), null)
  const saved = globalThis.fetch
  globalThis.fetch = () => Promise.reject(new TypeError('fetch failed'))
  assert.equal(await api.hydrate(), false)
  globalThis.fetch = saved
})

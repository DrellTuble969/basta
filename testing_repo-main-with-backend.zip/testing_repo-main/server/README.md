# Campus Connect server

Zero-dependency Node 22 backend (`node:http`, `node:sqlite`, `node:crypto`).

```
npm start            # http://localhost:4000
npm run dev          # restart on change
npm test             # API + client contract tests
npm run audit        # verify ledger chain + database consistency
npm run seed:reset   # wipe and re-seed demo data
npm run make-admin -- email
```

## API
Auth is `Authorization: Bearer <token>` from `/api/auth/login`. Errors are `{ "error": "message" }`.

| Method & path | Who | Purpose |
|---|---|---|
| `GET /api/health` | public | liveness + ledger size |
| `POST /api/auth/register`, `/login` · `GET /api/auth/me` | public / user | accounts |
| `GET /api/bootstrap` | optional | everything the caller may see, in one call |
| `GET /api/activities[?search&category&status&includeCancelled]` | public | list/filter |
| `POST/PUT/DELETE /api/activities[/:id]`, `POST /:id/cancel` | admin | manage |
| `POST /api/activities/:id/signup` | student | register (atomic seat count) |
| `POST /api/activities/:id/hours` `{hours}` | student | submit hours |
| `GET /api/records` | user | own (admin: all) |
| `POST /api/records/:id/approve` · `/reject` | admin | decide a pending submission |
| `GET/POST/PUT/DELETE /api/templates[/:id]` | admin | certificate templates |
| `GET /api/certificates` · `POST /api/certificates` | user · admin | list · grant |
| `GET /api/verify/:number` · `GET /verify/:number` | **public** | JSON · human page |
| `GET /api/ledger` · `GET /api/ledger/verify` | admin | entries · full audit |
| `GET /api/assets/:hash` | public | uploaded images (content-addressed) |

## How the ledger works
Each entry stores `hash = HMAC(key, canonical({seq, type, subject, actor, payload, prev, at}))`.
Changing any past entry breaks its hash and every link after it; without the server secret the
chain can't be recomputed. `reconcile()` additionally replays the ledger and compares it with the
live `records` and `certificates` tables.

## Files
`src/index.js` app + dispatch · `src/ledger.js` the core idea · `src/routes/*` endpoints ·
`src/db.js` schema · `src/crypto.js` JWT/scrypt/HMAC · `src/seed.js` demo data.

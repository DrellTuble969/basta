import react, { reactCompilerPreset } from '@vitejs/plugin-react'
import babel from '@rolldown/plugin-babel'
import { defineConfig } from 'vite'

const API = process.env.VITE_API_TARGET || 'http://localhost:4000'

// https://vite.dev/config/
export default defineConfig({
  build: {
    cssMinify: false,
    minify: false,
  },
  plugins: [
    react(),
    babel({ presets: [reactCompilerPreset()] }),
  ],
  server: {
    // Send API calls (and the public certificate-verification page) to the backend.
    proxy: {
      '/api': API,
      '/verify': API,
    },
  },
})

import { hydrate } from './api'

/**
 * Loads the current data from the server before the first render, so every screen
 * — including the signed-out pages — reads real data instead of empty fallbacks.
 * Returns false when the server cannot be reached.
 */
export const loadInitialData = hydrate

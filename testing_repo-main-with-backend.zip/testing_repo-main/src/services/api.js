/**
 * Persistence boundary — now backed by the Campus Connect server.
 *
 * The server is the source of truth. To keep every existing screen working
 * unchanged (they read synchronously through `store.read(...)`), this file keeps a
 * read-through cache in localStorage:
 *
 *   1. `hydrate()` pulls GET /api/bootstrap into the cache (on start-up, after
 *      sign-in, and after every change).
 *   2. Reads (`store.read`, `getAll`, `getForUser`, ...) come from that cache.
 *   3. Writes go to the server first; the cache is refreshed only if the server
 *      accepted them. Server error messages are surfaced to the UI as-is.
 */
const BASE = '/api'
const TOKEN_KEY = 'campus_token'
const SESSION_KEY = 'campus_session'

const read = (key, fallback) => {
  try {
    const value = JSON.parse(localStorage.getItem(key))
    return value ?? fallback
  } catch {
    return fallback
  }
}
const write = (key, value) => {
  try {
    localStorage.setItem(key, JSON.stringify(value))
  } catch (error) {
    console.warn(`Could not cache "${key}" locally`, error)
  }
  return value
}
export const store = { read, write }

async function request(method, path, body) {
  const token = localStorage.getItem(TOKEN_KEY)
  const headers = {}
  if (token) headers.Authorization = `Bearer ${token}`
  if (body !== undefined) headers['Content-Type'] = 'application/json'

  let response
  try {
    response = await fetch(`${BASE}${path}`, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
    })
  } catch {
    throw new Error('Cannot reach the Campus Connect server. Please try again.')
  }

  const text = await response.text()
  let data = null
  try {
    data = text ? JSON.parse(text) : null
  } catch { /* non-JSON error page */ }

  if (!response.ok) {
    if (response.status === 401 && token && !path.startsWith('/auth/')) {
      // The saved login expired or was revoked — return to the sign-in screen.
      clearSession()
      window.location.assign('/login')
    }
    throw new Error(data?.error || `Something went wrong (${response.status}).`)
  }
  return data
}

function clearSession() {
  localStorage.removeItem(TOKEN_KEY)
  localStorage.removeItem(SESSION_KEY)
  for (
    const key of [
      'campus_users',
      'campus_records',
      'campus_signups',
      'campus_certificates',
      'campus_certificate_templates',
    ]
  ) write(key, [])
}

/** Refresh the local cache from the server. Returns false if the server is unreachable. */
export async function hydrate() {
  let snapshot
  try {
    snapshot = await request('GET', '/bootstrap')
  } catch (error) {
    console.warn('Could not load data from the server:', error.message)
    return false
  }
  write('campus_activities', snapshot.activities)
  write('campus_users', snapshot.users)
  write('campus_records', snapshot.records)
  write('campus_signups', snapshot.signups)
  write('campus_certificates', snapshot.certificates)
  write('campus_certificate_templates', snapshot.templates)
  if (snapshot.user) write(SESSION_KEY, snapshot.user)
  else if (localStorage.getItem(TOKEN_KEY)) clearSession()
  return true
}

/** Run a write against the server, then refresh the cache so synchronous reads see it. */
async function mutate(method, path, body) {
  const result = await request(method, path, body)
  await hydrate()
  return result
}

const signIn = async (path, payload) => {
  const { token, user } = await request('POST', path, payload)
  localStorage.setItem(TOKEN_KEY, token)
  write(SESSION_KEY, user)
  await hydrate()
  return user
}

export const authService = {
  login: (email, password) => signIn('/auth/login', { email, password }),
  register: (data) => signIn('/auth/register', data),
  logout() {
    clearSession()
    hydrate() // reload the public data (activity list) for the signed-out screens
  },
}

export const activityService = {
  getAll(filters = {}) {
    const params = new URLSearchParams()
    if (filters.includeCancelled) params.set('includeCancelled', 'true')
    for (const key of ['search', 'category', 'status']) {
      if (filters[key]) params.set(key, filters[key])
    }
    const query = params.toString()
    return request('GET', `/activities${query ? `?${query}` : ''}`)
  },
  create: (data) => mutate('POST', '/activities', data),
  update: (id, data) => mutate('PUT', `/activities/${id}`, data),
  async delete(id) {
    await mutate('DELETE', `/activities/${id}`)
  },
  cancel: (id, reason) => mutate('POST', `/activities/${id}/cancel`, { reason }),
}

export const certificateTemplateService = {
  getAll: () => read('campus_certificate_templates', []),
  async save(template) {
    const { id, ...fields } = template
    await mutate(id ? 'PUT' : 'POST', id ? `/templates/${id}` : '/templates', fields)
    return this.getAll()
  },
  async delete(id) {
    await mutate('DELETE', `/templates/${id}`)
  },
}

export const certificateService = {
  getAll: () => read('campus_certificates', []),
  getForUser(userId) {
    return this.getAll().filter((certificate) => certificate.userId === userId)
  },
  grant: (details) => mutate('POST', '/certificates', details),
}

export const participationService = {
  getRecordsForUser(user) {
    return read('campus_records', []).filter((entry) =>
      entry.userId === user.id || entry.studentId === user.studentId
    )
  },
  getAllRecords: () => read('campus_records', []),
  async signUp(activityId) {
    await mutate('POST', `/activities/${activityId}/signup`, {})
    return true
  },
  // The server identifies the student from the sign-in token, so `user` is not sent.
  logHours: (activityId, hours) =>
    mutate('POST', `/activities/${activityId}/hours`, { hours: Number(hours) }),
  approveHours: (recordId) => mutate('POST', `/records/${recordId}/approve`, {}),
  rejectHours: (recordId) => mutate('POST', `/records/${recordId}/reject`, {}),
}

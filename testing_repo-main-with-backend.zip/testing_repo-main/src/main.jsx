import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import { loadInitialData } from './services/bootstrap'

const root = document.getElementById('root')

function showOffline() {
  const box = document.createElement('div')
  box.style.cssText = 'max-width:460px;margin:20vh auto;padding:24px;font:16px/1.5 system-ui,sans-serif;text-align:center'
  const title = document.createElement('h1')
  title.textContent = 'Campus Connect can’t reach its server'
  title.style.fontSize = '22px'
  const hint = document.createElement('p')
  hint.textContent = 'Start the backend (npm run server), then try again.'
  const retry = document.createElement('button')
  retry.textContent = 'Try again'
  retry.style.cssText = 'padding:10px 18px;font:inherit;cursor:pointer'
  retry.onclick = () => window.location.reload()
  box.append(title, hint, retry)
  root.replaceChildren(box)
}

loadInitialData().then((online) => {
  if (!online) return showOffline()
  createRoot(root).render(
    <StrictMode>
      <App />
    </StrictMode>,
  )
})
